<?php



?>
<div class="main-sidebar-inner">
<?php
       dynamic_sidebar('main-sidebar');
?>
</div>
