<?php

get_header();

?>
<h1>EMS</h1>

<?php

get_footer();
?>