<?php
/*
* This templete is used to display header
*/
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
     <head>
	    <title>
		  <?php echo get_the_title(); ?> |
		  <?php bloginfo('name') ?>
		</title>
    <?php wp_head() ?>
	</head>
	<body>
		<script type="text/javascript">
