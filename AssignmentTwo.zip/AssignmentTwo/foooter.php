<?php
/*
* This templete is used to display footer
*/
?>
</body>
<?php wp_footer() ?>
		 </html
