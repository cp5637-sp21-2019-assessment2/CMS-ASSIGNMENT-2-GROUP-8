<?php
/*
* This templete is used to display sidebar 
*/
?>