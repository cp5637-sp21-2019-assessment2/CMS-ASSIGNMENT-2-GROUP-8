<?php
/*
* This templete is used to display single posts 
*/
get_headers();
?>

		 <h1>Hello folks! I am learning the theme development</h1>

	<?php
	get_footer();
	?>