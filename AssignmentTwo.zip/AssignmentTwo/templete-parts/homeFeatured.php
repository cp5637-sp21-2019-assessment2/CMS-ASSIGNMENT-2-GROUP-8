<?php
/*
* Homepage Featured Area
*/
?>
<h1>Homepage Featured Area</h1>
