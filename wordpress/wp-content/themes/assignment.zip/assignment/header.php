<?php
?>
<!DOCTYPE html>
<html>
<meta charset="utf-8"/>
    <head>
       <title> 
        <?php echo get_the_title(); ?>|
        <?php bloginfo( 'name' ); ?>
    </title>
<?php wp_head() ?>   
</head>
    <body>
    