</body>
<?php wp_footer() ?>
</html>